import nltk

# Download specific packages from command line
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('gutenberg')  # optional